-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Nov 20, 2022 at 05:07 PM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.2.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laraveldb`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `title`, `description`, `created_at`) VALUES
(1, 'ghg', 'fhgfhgfh', '2022-02-01 15:55:19');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2022_01_08_113218_create_user', 1),
(3, '2022_01_08_211734_create_tasks_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `gender` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT 1,
  `parentId` int(11) DEFAULT NULL,
  `type` tinytext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`) USING HASH
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `created_at`, `gender`, `remember_token`, `photo`, `status`, `parentId`, `type`) VALUES
(1, 'Test1', 'test1@g.com', '$2y$10$Wh9PDpcF0hcQMrGlLV6bY.7ucfNTabg5DAvZwQzgo/fzHOdYdZBym', '2022-11-20 09:53:00', '1', '6Z3m6M6sgCvGcuVgGOBaXkhneVARFHDUfSfxwxbTd2mO3GoVuw0Tt95dsHhU', 'c3NzLmpwZWc=', 1, NULL, 'folder'),
(2, 'Test2', 'test2@g.com', '$2y$10$a.r7YfVXP8qjCVorf5q.y.tonoZLaW4hdy1luJdnQeTqDLHZfAuhy', '2022-11-20 09:55:00', '2', 'Gn2BYZuZTgYGfz5CMoztJTTYYMGD6o1H3CC3k6fRUcB4VAQWeWY91cqR77kW', 'V2hhdHNBcHAgSW1hZ2UgMjAyMS0xMC0xMCBhdCAxMi4xNi40NyBQTS5qcGVn', 1, 0, 'folder'),
(3, 'Test3', 'test3@g.com', '$2y$10$o4gAQ/4zv/20TXxSEHCHJu9LF64YMroW5eWDO7Pf930USpAqGDNzK', '2022-11-20 09:58:12', '1', 'X8IIEqaMpN1iXxbSJkHq4M16fRUXaAtyrM0uxoH1', NULL, 1, 1, 'subfolder'),
(4, 'Test4', 'test4@g.com', '$2y$10$Jz84jk88hdYZk79ThXKGyOExv8fejzHvDvUpcon7zGvSlWiTvgTna', '2022-11-20 09:58:44', '1', '0WqqKC9dLYqrm3v4hGcdkRjyTNhlfIVSTbF0TFaJ5i3uMbAo2Qeh1GX0q2nx', NULL, 1, 3, 'subfolder'),
(5, 'Test5', 'test5@g.com', '$2y$10$QoyJW/11p75CvyBX/ylYVe1vRlKninEgaM56pVvM5As90o5QbgIXy', '2022-11-20 10:00:42', '2', 'X8IIEqaMpN1iXxbSJkHq4M16fRUXaAtyrM0uxoH1', 'V2hhdHNBcHAgSW1hZ2UgMjAyMS0xMC0xMCBhdCAxMi4xNi41MSBQTS5qcGVn', 1, 4, 'sfolder'),
(6, 'Test6', 'test6@g.com', '$2y$10$85Wgwa4MQRCoNCDnb7vPAeGQH/H7Y25cc4hrAf.dk3RaYtBl0xFU2', '2022-11-20 10:46:12', '2', 'uooy4GaZ2cdmz3BC3T3XDCaf9gfz0XBYbu89Hdarsf9PWJhYRkdoxBTHi3bY', 'V2hhdHNBcHAgSW1hZ2UgMjAyMS0xMC0xMCBhdCAxMi4xNi41NSBQTSAoMSkuanBlZw==', 1, 2, 'subflder'),
(7, 'Test7', 'test7@g.com', '$2y$10$M0BQIpw8dqZVZOh5QvTr.OcplWJyezUPpmaT/3Q5uIdejQO5lloY6', '2022-11-20 16:33:09', '1', 'k9ssNFmS5zHEFZ2ssFYOTJ5Sxjdw92QmwOgwdjHtBMSAwEhleUBuOkN33nGf', NULL, 1, 2, 'Folder');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
