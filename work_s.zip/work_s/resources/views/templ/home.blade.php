 @include('templ.header')
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <!-- Sample page content -->
    <div class="container">
        <h3>Home</h3>
  <div class="row">
	   <div class="list">
       
       </div> 
	    
	    <!--<div class="card mb-3 loadid" >Loading Pages...</div>    -->                                                                          
   </div>
      </div>
	   
	 
 
	   
@include('templ.footer')