 <footer  class="navbar navbar-default" >
    <div class="container text-center" style="font-size: 14px;">
      <small>Copyright &copy;   Designed by <a href="https://" target="_blank" rel="noopener">Test</a> </small>
    </div>
  </footer>
</body>
  
</html>
