@include('templ.header')
<div class="container">
<div  class="col-md-12">
@include('templ.leftmenu')

<div  class="col-md-9 row" style="border: 1px solid #ddd;margin-left:2%">
<div id="uid"></div>
<div style="border-bottom: 1px solid #ddd;margin-bottom:4%" >
<h4>View </h4></div>
 @foreach ($children_details as $user)
      <div  class="col-md-3 form-group">Id </div>
      <div class="col-md-9 form-group">{{ $user->id }}</div> 
      <div  class="col-md-3 form-group">Name </div>
      <div class="col-md-9 form-group">{{ $user->name }}</div> 
	  
      <div class="col-md-3 form-group" >Parent </div> 
      <div class="col-md-9 form-group" >
            <?php
       if(isset($user['parentname']->name) && $user['parentname']->name!='')  
            echo  $user['parentname']->name;
             else
             echo '---'; 
             ?>
      </div> 
      <div class="col-md-3 form-group" >Type </div> 
      <div class="col-md-9 form-group" >{{ $user->type }}</div> 
	  
     
	  <div class="col-md-3 form-group" >Gender </div>
      <div class="col-md-9 form-group" >{{ $user->gender== 1? 'Male' : 'Female' }}</div>
      <div class="col-md-9 form-group" >
       <?php 
       $rows=$user['children']->toArray(); 
        

   
       echo buildTrees($rows,$user->name,1);
       if( isset($_SERVER['HTTPS'] ) ) {$https='https://';}else{$https='http://';}
       ?>
       </div>
       <div class="col-md-12 form-group" >
       <div class="col-md-3 form-group" >Created At </div>
       <div  class="col-md-9 form-group">{{ date("d/m/Y",strtotime($user->created_at)) }}</div> 
       </div>
       <div class="col-md-12 form-group" >
      <?php if($user->photo != ''){?>
	  <div  class="col-md-3 form-group">Photo </div>
      <div class="col-md-9 form-group"><img src="<?php echo $https.$_SERVER['HTTP_HOST'];?>/work_s/uploads/{{ base64_decode($user->photo) }}" width="100" height="100" /></div> 
	<?php }?>  
    </div>
    <div class="col-md-12 form-group" style="border-bottom:1px solid #ccc;"></div>
      @endforeach
</div>

</div>
</div>
<?php 
 function buildTrees(array $rows,$name,$c){
    $tab='';
    if(count($rows)>0){ 
        $sty='style="padding-left:'.(10*$c).'%"' ;
        $tab.='<div '.$sty.'>';
        $tab.='Children of '.$name;
        foreach($rows as $tree1)
        {
         
            $tab.='<div>Id : '.$tree1['id'].'</div>';
            $tab.='<div>Name : '.$tree1['name'].'</div>';
            $tab.='<div>Type : '.$tree1['type'].'</div>';
            
            if(count($tree1['children'])>0)
            {
                $tab.= buildTrees($tree1['children'],$tree1['name'],$c);
            }
            $c++;
        }
        $tab.='</div>';
        return $tab;
 }

 }
  
  ?>
@include('templ.footer')

 