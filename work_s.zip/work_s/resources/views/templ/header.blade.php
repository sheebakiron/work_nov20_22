 <!DOCTYPE html>
<html lang="en">
  
<head>
    <title>Bootstrap NavBar Example</title>
    <meta charset="utf-8" />
    <!-- Include bootstrap, CSS and jQuery CDN -->
    <meta name="viewport" content=
        "width=device-width, initial-scale=1" />
    <link rel="stylesheet" href=
"https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" />
    <script src=
"https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js">
    </script>
    <script src=
"https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js">
    </script>
</head>
<body>
    <!-- Add <nav> tag with .navbar and
         .navbar-default class -->
    <nav class="navbar navbar-default" >
  
        <!-- Add navbar content -->
        <div class="container-fluid" style="display:inline;font-size: 14px;">
  
            <!-- Include .navbar-header class 
                 in <div>  (optional)-->
            
  
            <!-- Include navbar list -->
            <ul class="nav navbar-nav" style="flex-direction: row;">
                <li <?php
                if( isset($_SERVER['HTTPS'] ) ) {$https='https://';}else{$https='http://';}
                    $host=$_SERVER['HTTP_HOST'];
                if(Request::path()=='home') {?> class="active" <?php }?>><a href="<?php echo $https.$_SERVER['HTTP_HOST'];?>/work_s/home">
                    Home 
                </a></li>
				@guest
                <li <?php if(Request::path()=='register') {?> class="active" <?php }?>><a href="<?php echo $https.$_SERVER['HTTP_HOST'];?>/work_s/register" >Signup</a></li>
                <li <?php if(Request::path()=='login') {?> class="active" <?php }?>><a href="<?php echo $https.$_SERVER['HTTP_HOST'];?>/work_s/login" >Login</a></li>
			 
				  @else
                <li><a href="<?php echo $https.$_SERVER['HTTP_HOST'];?>/work_s/signout">Signout</a></li>
				  
				 
				  @endguest
            </ul>
        </div>
    </nav>
  