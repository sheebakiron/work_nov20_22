@include('templ.header')
<div class="container">
<div  class="col-md-12">
@include('templ.leftmenu')

<div  class="col-md-9 row" style="border: 1px solid #ddd;margin-left:2%">
 
<div style="border-bottom: 1px solid #ddd;margin-bottom:4%" >
 <?php print_r($user_details);?>
</div>

</div>
</div>
@include('templ.footer')

 