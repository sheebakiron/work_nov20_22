<?php 
if( isset($_SERVER['HTTPS'] ) ) {$https='https://';}else{$https='http://';}
                    $host=$_SERVER['HTTP_HOST'];
                    ?>
<div  class="col-md-3 row" style="border: 1px solid #ddd;">
<div><h4>Menu</h4></div>
<ul class="list-group">
<li class="list-group-item"><a href="<?php echo $https.$_SERVER['HTTP_HOST'];?>/work_s/api/userlist?status=1"  >Users</a></li>
<li class="list-group-item"><a href="<?php echo $https.$_SERVER['HTTP_HOST'];?>/work_s/profile">Profile</a></li>
<li class="list-group-item"><a href="<?php echo $https.$_SERVER['HTTP_HOST'];?>/work_s/api/usersresponse?status=1" target="_blank"  >Users(In Json output)</a></li>
</ul>
</div>
 