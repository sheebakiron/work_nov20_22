<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*Route::get('/', function () {
    return view('welcome');
});
*/



use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CustomAuthController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/
 
//use App\Http\Controllers\Client\API\ClientAPIController;

//Route::get('/login', [CustomAuthController::class, 'index']);
//This  is what is causing the error, I have to remove it 
//The 'uses' => 'uses'

 /*Route::get('/login', function () {
    return view('auth.signin');
});
Route::resource('register', 'RegisterController');*/
//-----------------------------------------------------
//-----test block--------------
Route::get('/','HomeController@index');
Route::get('home','HomeController@index');
Route::get('login','HomeController@login');
Route::get('register','HomeController@register');
Route::get('signout','HomeController@signout');
Route::post('usercreate','HomeController@insert');
Route::get('profile','HomeController@view');
Route::post('customLogin','HomeController@customLogin');
Route::get('upload','HomeController@upload');
Route::get('changepass','HomeController@changepass');
Route::post('passupdate','HomeController@passupdate');
Route::post('photoupdate','HomeController@photoupdate');
 
//-----test block--------------
Route::get('userlist','HomeController@userlist');
Route::get('api/userlist','HomeController@users');
Route::get('userlists','HomeController@userlists');
Route::get('logincheck','HomeController@logincheck');