<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Auth;
use Hash;
use DB;
use Session;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\User as User;
use Response;
 

class HomeController extends Controller
{
  
    //
	 public function index()
	    {
			$id=Auth::id();
			 if($id>0){
				return $this->view(); 
			}else{
		            return $this->register();
			 }
        }
		 
        public function register()
	    {
			 $parentId = DB::select('select id,name from users where status=1   order by name');
             return view('templ.stud_create',['parentId'=>$parentId]);	
        }
       
	     public function insert(Request $request)
		{  
			$file = '';
			if($request->file('photo')){
			$file = $request->file('photo'); 
			}
			$password = Input::get('password');
            $email = Input::get('email');
			$parentId= Input::get('parentId');
            $rules = array('email' => 'unique:users,email','password' => 'required|string|min:8');
            $input['email'] = $email;$input['password'] = $password;
			$validator = Validator::make($input, $rules);
			$emailflag=0;
			$pss=Hash::make($password);
			$data = $request->all();
			$data['password']=$pss;
			unset($data['_token']);
			if ($validator->fails())
			{ 
			     $postdata['data'][]=$data; 
				 $postdata['msg']='Duplicate entry for email or minimum length for password is 8 with alphanumeric characters!!';
				 return view('templ.stud_create')->with($postdata);	
			}else{
				 //upload image
				 if($file!='')
				 { 
					$ext=$file->getClientOriginalExtension();
					//Move Uploaded File
					$destinationPath = 'uploads';
					if ($ext !== 'gif' && $ext !== 'png' && $ext !== 'jpg' && $ext !== 'jpeg' && $ext !== 'JPG' && $ext !== 'JPEG' && $ext !== 'GIF') 
					{$mssg='pls upload jpg or png or gif files!';}else{
					$file->move($destinationPath,$file->getClientOriginalName());
					$photo=$file->getClientOriginalName();
					$data['photo']=base64_encode($photo);
					$mssg='';
					}
					
					if($mssg!=''){
					Session::flash('messagechphoto',$mssg);
					}
				 }
				//----------------------------------------------------
				 $check = $this->create($data);
				 Session::flash('message','You have successfully Registered! Pls login to view your account');
				 return redirect("login");
				
			}
		}
		 public function create(array $data)
			{
				
				DB::table('users')->insert($data);
			}
		 
		public function login() {
			$id=Auth::id();
			 if($id>0){
				return $this->view(); 
			 }else{
               return view('templ.stud_login');
			 }
        }
		public function customLogin(Request $request)
		{
			 
	   
			$credentials = $request->only('email', 'password');
			if (Auth::attempt($credentials)) {
				return redirect()->intended('api/userlist?status=1')
							->withSuccess('Signed in');
			}
			Session::flash('message','Login details are not valid');
				 return redirect("login");
	  
			//return redirect("login")->withSuccess('Login details are not valid');
		}
		 
		public function signout(Request $request) {
		  Auth::logout();
		  return redirect('/login');
		}
		 
		public function view()
	    {
			$id=Auth::id();
			 if($id>0){ 
 			 
			 //get children
			 $children_details = User::with(['parentname' => function ($query) {
										$query->select('id', 'name');
									}])->with('children')
			                    ->where('status',1)->where('id',$id)
								->select('id','name','type','photo','gender','created_at','parentId')
								->get();
								 
		     //-------------------------------
             return view('templ.stud_view',['children_details'=>$children_details]);
			 }else{return redirect("login");}
        }     
		public function users()
	    {
			$id=Auth::id();
			 if($id>0){ 
 			 
			 //get children
			 $children_details = User::with(['parentname' => function ($query) {
										$query->select('id', 'name');
									}])->with('children')
			                    ->where('status',1)
								->select('id','name','type','photo','gender','created_at','parentId')
								->get();
								 
		     //-------------------------------
             return view('templ.stud_view',['children_details'=>$children_details]);
			 }else{return redirect("login");}
        }  
		public function usersresponse(Request $request)
		{
			    $input = $request->all();
			    if(Auth::id() && Auth::id()!='')
				{
					$id=Auth::id();
					$input['user']=$id;
				}
				$error = Validator::make($input, [
					        'status'   => 'required',
						]);
				if ($error->fails()) {
							$result = array("Response" => $error->messages()->first());
							return Response::json($result);
				} else {
								if(isset($input['status']) && $input['status']!=''){
					            $status=$input['status'];
								}else{$status=1;}
								$user_details = User::with('children')->where('status',$status)
								->whereNull('parentId')->select('id','name','type')
								->get();
								$result = array("Response" => $user_details);
								return Response::json($result);
				}
		     
			 
		}
		//--------------login check-------------------
		public function logincheck(Request $request)
		{
			$input=$request->all();$email=$input['email'];$password=$input['password'];
			$error = Validator::make($input, [
				'email' => 'required',
				'password' => 'required',
			]);
			$err='';
			if ($error->fails()) {
				$result = array("statusText" => 1);
				return Response::json($result);
			} 
			else 
			{
				        
						if (Auth::attempt(['email' => $email, 'password' => $password, 'status' => 1])) 
						{
							$result = array("statusText" => 2);
							return Response::json($result);
			            }else{
							$result = array("statusText" => 3);
							return Response::json($result);
						}
						
			}
			 
			
			 
		}
		 
 }