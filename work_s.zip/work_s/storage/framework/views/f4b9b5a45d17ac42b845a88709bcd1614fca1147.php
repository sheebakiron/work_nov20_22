<?php echo $__env->make('templ.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container">
<div  class="col-md-12">
<?php echo $__env->make('templ.leftmenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div  class="col-md-9 row" style="border: 1px solid #ddd;margin-left:2%">
 
<div style="border-bottom: 1px solid #ddd;margin-bottom:4%" >
 <?php print_r($user_details);?>
</div>

</div>
</div>
<?php echo $__env->make('templ.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

 