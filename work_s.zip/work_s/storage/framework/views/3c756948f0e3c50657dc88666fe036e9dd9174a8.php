<div  class="col-md-3 row" style="border: 1px solid #ddd;">
<div><h4>Menu</h4></div>
<ul class="list-group"><li class="list-group-item"><a href="profile">Profile</a></li><li class="list-group-item"><a href="upload">Upload Image</a></li><li class="list-group-item"><a href="changepass">Change Password</a></li></ul>
</div>
