<?php echo $__env->make('templ.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container">
  <h2 class="text-center">SignIn</h2>
  <br>
  <span id="spanId"></span>
  <br> 
   <form action = "customLogin" name="frm" method = "post" class="form-group" style="width:70%; margin-left:15%;" action="/action_page.php">
  <?php if(session()->has('message')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('message')); ?>

    </div>
<?php endif; ?>
 <?php if(isset($msg)){echo '<label class="form-group" style="color:red;">'.$msg.'</label><br>';}?>
  <input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>"><input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>">
 	<label>Email:</label>
    <input type="email" class="form-control" placeholder="Enter Email"   name="email" required>
	<label>Password:</label>
    <input type="password" class="form-control" placeholder="Enter password" name="password"   required>
     
<br>
    <button type="button"  value = "submit" class="btn btn-primary" onclick="login_validate();">Submit</button>
  </form>
</div>
<script>
function login_validate(){
  var app=this;
  var email=document.frm.email.value;
  var password=document.frm.password.value;
    const uri = '/work_s/logincheck?email=' + email + '&password=' + password;
    fetch(uri, {
  method: 'GET', // or 'PUT'
  headers: {
    'Content-Type': 'application/json',
  },
})
  .then((response) => response.json())
  .then((data) => {
    let statusText=JSON.stringify(data.statusText);
    if(statusText==1){
      document.getElementById("spanId").innerHTML='Please Enter Login Details';
    }
    if(statusText==2){
      window.location.href='api/userlist?status=1'; 
    }
    if(statusText==3){
      document.getElementById("spanId").innerHTML='Invalid login details';
    }
  })
  .catch((error) => {
    console.error('Error:', error);
  });
}
    
</script>

<?php echo $__env->make('templ.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>