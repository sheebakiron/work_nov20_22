 <?php echo $__env->make('templ.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <!-- Sample page content -->
    <div class="container">
        <h3>Home</h3>
  <div class="row">
	   <div class="list">
       
       </div> 
	    
	    <!--<div class="card mb-3 loadid" >Loading Pages...</div>    -->                                                                          
   </div>
      </div>
	   
	 <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script>
var currentscrollHeight = 0;
var count = 0;
var pagecount = 2;
$(window).on("scroll", function () {

  const scrollHeight = $(document).height();
  const scrollPos = Math.floor($(window).height() + $(window).scrollTop());
  const isBottom = scrollHeight - 100 < scrollPos;
  const list = $(".list");
  
  if (isBottom && currentscrollHeight < scrollHeight) {
//---------------------
$.ajax({url: "indexajax/"+pagecount, success: function(result){
	 list.append(result);
	 // $(".loadid").hide();
  }});
pagecount++;
    currentscrollHeight = scrollHeight;
  }
});
</script>
	 
	   
<?php echo $__env->make('templ.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>