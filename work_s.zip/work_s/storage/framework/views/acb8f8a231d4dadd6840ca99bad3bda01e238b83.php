<?php echo $__env->make('templ.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container">
<div  class="col-md-12">
<?php echo $__env->make('templ.leftmenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div  class="col-md-9 row" style="border: 1px solid #ddd;margin-left:2%">
<div id="uid"></div>
<div style="border-bottom: 1px solid #ddd;margin-bottom:4%" >
<h4>View Profile</h4></div>
 <?php $__currentLoopData = $children_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
      <div  class="col-md-3 form-group">Name </div>
      <div class="col-md-9 form-group"><?php echo e($user->name); ?></div> 
	  <!-- <div class="col-md-3 form-group" >Email </div> 
      <div class="col-md-9 form-group" ><?php echo e($user->email); ?></div>  -->
      <div class="col-md-3 form-group" >Parent </div> 
      <div class="col-md-9 form-group" >
            <?php
       if(isset($user['parentname']->name) && $user['parentname']->name!='')  
            echo  $user['parentname']->name;
             else
             echo '---'; 
             ?>
      </div> 
      <div class="col-md-3 form-group" >Type </div> 
      <div class="col-md-9 form-group" ><?php echo e($user->type); ?></div> 
	  <div  class="col-md-3 form-group">Created </div>
      <div  class="col-md-9 form-group"><?php echo e(date("d/m/Y",strtotime($user->created_at))); ?></div> 
	  <div class="col-md-3 form-group" >Gender </div>
      <div class="col-md-9 form-group" ><?php echo e($user->gender== 1? 'Male' : 'Female'); ?></div>
      <?php if($user->photo != ''){?>
	  <div  class="col-md-3 form-group">Photo </div>
      <div class="col-md-9 form-group"><img src="uploads/<?php echo e(base64_decode($user->photo)); ?>" width="100" height="100" /></div> 
	<?php }?>  
       <?php 
       $rows=$user['children'];
       $tree = buildTree($rows);
       print_r( $tree );
       ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

</div>
</div>
<?php 
function buildTree(array $elements, $parentId = 0) {
      $branch = array();
  
      foreach ($elements as $element) {
          if ($element['parentId'] == $parentId) {
              $children = buildTree($elements, $element['id']);
              if ($children) {
                  $element['children'] = $children;
              }
              $branch[] = $element;
          }
      }
  
      return $branch;
  }
  ?>
<?php echo $__env->make('templ.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

 