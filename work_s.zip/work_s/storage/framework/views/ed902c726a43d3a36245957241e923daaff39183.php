<?php echo $__env->make('templ.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container">
  <h2 class="text-center">Signup</h2>
  <br><?php
  $name='';$dob='';$gender='';$email='';
   if(isset($data[0])){$name=$data[0]['name'];$dob=$data[0]['dob'];$gender=$data[0]['gender'];$email=$data[0]['email'];}?>
   <form action = "usercreate" method = "post" class="form-group" style="width:70%; margin-left:15%;" action="/action_page.php">
 <?php if(isset($msg)){echo '<label class="form-group" style="color:red;">'.$msg.'</label><br>';}?>
  <input type = "hidden" name = "remember_token" value = "<?php echo csrf_token(); ?>"><input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>">

    <label class="form-group">Name:</label>
    <input type="text" class="form-control" placeholder="First Name" name="name"  value="<?php echo $name; ?>" required>
	<label>Email:</label>
    <input type="email" class="form-control" placeholder="Enter Email" value="<?php echo $email; ?>" name="email" required>
	<label>Password:</label>
    <input type="password" class="form-control" placeholder="Enter password" name="password" pattern="([a-zA-Z0-9]).{8,}" title="Must contain Alphanumeric characters, and at least 8 or more characters" required>
    <label>Date of Birth:</label>
    <input type="date" class="form-control"   name="dob" value="<?php echo $dob; ?>">
  <label>Gender:</label>
  <select class="form-control" name="gender">
  <option value="Male"  <?php if($gender=='Male'){echo 'selected';} ?> >Male</option>
    <option value="Female" <?php if($gender=='Female'){echo 'selected';} ?>>Female</option>
	<option value="Others" <?php if($gender=='Others'){echo 'selected';} ?>>Others</option>
  </select>
<br>
    <button type="submit"  value = "Add student" class="btn btn-primary">Submit</button>
  </form>
</div>

<?php echo $__env->make('templ.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>